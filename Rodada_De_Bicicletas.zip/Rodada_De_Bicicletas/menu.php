    <nav id="menu" class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="#">Navbar</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <!-- <li id="menu-mapas" class="nav-item" onmouseover="activaParpadeo(this)" onmouseleave="desactivaParpadeo(this)"> -->
          <li id="menu-mapas" class="nav-item">
            <a class="nav-link" href="mapas.php">Mapas</a>
          </li>
          <li id="menu-twitter" class="nav-item">
            <a class="nav-link" href="twitter.php">Twitter</a>
          </li>
          <li id="menu-youtube" class="nav-item">
            <a class="nav-link" href="video.php">YouTube</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Facebook</a>
          </li>
        </ul>
      </div>
    </nav>